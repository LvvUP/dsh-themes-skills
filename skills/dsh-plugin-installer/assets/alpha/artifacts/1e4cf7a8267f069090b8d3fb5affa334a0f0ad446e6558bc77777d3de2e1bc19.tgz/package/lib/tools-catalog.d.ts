import type { Context } from '@deepseek-ai/cordis';
import type { JumpServerApi } from './api.js';
/** Register read-only asset / account / node / profile tools. */
export declare function registerCatalogTools(ctx: Context, api: JumpServerApi): void;
/** Register optional admin CRUD tools. */
export declare function registerAdminTools(ctx: Context, api: JumpServerApi): void;
//# sourceMappingURL=tools-catalog.d.ts.map