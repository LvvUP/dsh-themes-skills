import type { Context } from '@deepseek-ai/cordis';
import type { JsonValue } from '@deepseek-ai/dsh-session';
import type { JumpServerApi } from './api.js';
import type { ResolvedConfig } from './config.js';
import { type ClientProtocolData, type ConnectionTokenInfo } from './types.js';
import type { SessionManager } from './sessions.js';
/** Register connect / exec / SFTP / disconnect tools. */
export declare function registerRuntimeTools(ctx: Context, api: JumpServerApi, sessions: SessionManager, config: ResolvedConfig): void;
/**
 * Open KoKo SSH after createClientProtocol. Expire the token if endpoint
 * resolve or SSH fails — that method already popped the id from leftoverIds.
 */
export declare function openKokoSession(api: Pick<JumpServerApi, 'expireConnectionToken'>, sessions: SessionManager, config: ResolvedConfig, input: {
    token: ConnectionTokenInfo;
    client: ClientProtocolData;
    assetId: string;
    account: string;
    protocol: string;
}, signal?: AbortSignal): Promise<JsonValue>;
//# sourceMappingURL=tools-runtime.d.ts.map