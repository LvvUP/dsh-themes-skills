import type { ContentBlock } from '@deepseek-ai/dsh-llm';
import type { JsonValue } from '@deepseek-ai/dsh-session';
/** Pretty-print a canonical JSON tool result for the model. */
export declare function renderJson(_args: unknown, value: JsonValue): ContentBlock[];
/** Shared output schema for structured JSON payloads. */
export declare const jsonOutput: {
    schema: {
        type: "json";
    };
    render: typeof renderJson;
};
//# sourceMappingURL=render.d.ts.map