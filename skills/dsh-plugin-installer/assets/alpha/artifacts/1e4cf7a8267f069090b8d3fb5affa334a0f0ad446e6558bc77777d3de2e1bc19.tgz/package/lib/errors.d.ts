/** Flatten a fetch/ssh2 failure so the tool result shows the OS/TLS code. */
export declare function formatNetworkError(error: unknown): string;
//# sourceMappingURL=errors.d.ts.map