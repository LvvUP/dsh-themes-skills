import { type ResolvedAccountRef } from './account.js';
import { type AccountSummary, type AssetSummary, type ConnectionTokenInfo, type KokoEndpoint, type ListPage } from './types.js';
import type { JumpServerClient } from './client.js';
import type { ClientProtocolData } from './types.js';
/** Query for listing the current user's assets. */
export interface ListAssetsQuery {
    search?: string;
    limit?: number;
    offset?: number;
    address?: string;
    name?: string;
    type?: string;
    category?: string;
}
/** Fields accepted when creating a host. */
export interface CreateHostInput {
    name: string;
    address: string;
    platform: number | string;
    nodes: string[];
    comment?: string;
    is_active?: boolean;
    protocols?: Array<{
        name: string;
        port: number;
    }>;
}
/** Domain operations over JumpServer Core. */
export declare class JumpServerApi {
    private readonly client;
    constructor(client: JumpServerClient);
    /** Current user profile -- useful to verify auth and org. */
    profile(signal?: AbortSignal): Promise<unknown>;
    /** Assets the authenticated user is permitted to use. */
    listAssets(query?: ListAssetsQuery, signal?: AbortSignal): Promise<ListPage<AssetSummary>>;
    /** One permitted asset, falling back to the admin asset endpoint. */
    getAsset(assetId: string, signal?: AbortSignal): Promise<AssetSummary>;
    /** Map a tool account argument to the id/username Core expects. */
    resolveAccount(assetId: string, account: string, signal?: AbortSignal): Promise<ResolvedAccountRef>;
    /** Accounts the user may use on an asset. */
    listAccounts(assetId: string, signal?: AbortSignal): Promise<ListPage<AccountSummary>>;
    /** Nodes the current user can see. */
    listNodes(signal?: AbortSignal): Promise<ListPage<Record<string, unknown>>>;
    /** Host platforms (needed when creating assets). */
    listPlatforms(signal?: AbortSignal): Promise<ListPage<Record<string, unknown>>>;
    /** Create a host asset. Requires JumpServer asset admin permission. */
    createHost(input: CreateHostInput, signal?: AbortSignal): Promise<unknown>;
    /** Patch a host asset. */
    updateHost(hostId: string, patch: Record<string, unknown>, signal?: AbortSignal): Promise<unknown>;
    /** Delete a host asset. */
    deleteHost(hostId: string, signal?: AbortSignal): Promise<void>;
    /** Create a connection token for KoKo / other terminal components. */
    createConnectionToken(input: {
        asset: string;
        account: string;
        protocol: string;
        connectMethod: string;
        inputUsername?: string;
        reusable?: boolean;
    }, signal?: AbortSignal): Promise<ConnectionTokenInfo>;
    /** Decode the KoKo SSH endpoint for a connection token. */
    getClientProtocol(tokenId: string, signal?: AbortSignal, fallback?: {
        id?: string;
        value?: string;
    }): Promise<ClientProtocolData>;
    /** Best-effort expire so a retried connect_method does not leave a live token. */
    expireConnectionToken(tokenId: string): Promise<void>;
    /**
     * Create a token with a native KoKo connect_method and resolve client-url.
     * Retries ssh_guide if ssh_client is rejected.
     */
    createClientProtocol(input: {
        asset: string;
        account: string;
        protocol: string;
        inputUsername?: string;
        reusable?: boolean;
    }, signal?: AbortSignal): Promise<{
        token: ConnectionTokenInfo;
        client: ClientProtocolData;
    }>;
    /**
     * KoKo SSH host/port. Database `web_cli` client-url returns HTTP, so SQL
     * still goes over the same SSH listener the host tools already use.
     */
    resolveKokoSshEndpoint(signal?: AbortSignal): Promise<KokoEndpoint>;
}
//# sourceMappingURL=api.d.ts.map