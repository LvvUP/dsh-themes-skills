/**
 * DeepSeek Harness plugin: manage JumpServer assets and operate on them through KoKo.
 * @module @jumpserver-east/jumpserver-dsh
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import { type Config as PluginConfig } from './config.js';
export declare const name = "jumpserver";
export declare const inject: string[];
export type Config = PluginConfig;
export declare const Config: z<PluginConfig>;
/** Mount JumpServer tools, prompt guidance, and KoKo session cleanup. */
export declare function apply(ctx: Context, config: PluginConfig): void;
export { JumpServerApi } from './api.js';
export { JumpServerClient, buildRequestUrl, signingPath } from './client.js';
export { signAccessKey, buildSigningString, httpDate } from './auth.js';
export { parseJmsUrl, parseClientUrlPayload } from './jms-url.js';
export { SessionManager } from './sessions.js';
export { JumpServerError } from './types.js';
export { nativeConnectMethods } from './connect-method.js';
export { canonicalProtocol, isDatabaseProtocol, pickAssetProtocol, pickConnectProtocol } from './protocol.js';
export { classifySql, assertSqlAllowed } from './sql-kind.js';
//# sourceMappingURL=index.d.ts.map