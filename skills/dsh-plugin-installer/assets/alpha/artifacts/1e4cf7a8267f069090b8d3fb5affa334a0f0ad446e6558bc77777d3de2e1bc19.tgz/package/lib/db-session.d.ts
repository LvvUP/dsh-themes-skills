import type { Client } from '#ssh2';
import type { ExecResult, FileReadResult, SshConnection } from './sessions.js';
/** Strip CSI / OSC / leftover C0 so prompt matching sees plain text. */
export declare function stripAnsi(text: string): string;
/** True when KoKo/usql is waiting for the next statement. */
export declare function looksLikeDbPrompt(text: string): boolean;
/** usql prints this only after the driver session is actually up. */
export declare function looksLikeUsqlReady(text: string): boolean;
/** Reply to linenoise/usql cursor and window queries so the prompt is flushed. */
export declare function terminalQueryReplies(chunk: string): string[];
/** True when the banner says the database never came up. */
export declare function looksLikeDbConnectError(text: string): boolean;
/** Terminate SQL for usql; leave Redis / Mongo commands alone. */
export declare function formatDbCommand(sql: string, protocol: string): string;
/** Drop the echoed command and the trailing prompt from a PTY capture. */
export declare function extractDbResult(captured: string, command: string): string;
/** A query is done only when a *new* prompt arrives after some output (not the idle prompt already on screen). */
export declare function isStatementComplete(suffix: string): boolean;
/**
 * KoKo database tokens reject SSH exec (`not ssh asset connection token`).
 * SQL goes through an interactive PTY that usql / sqlplus / redis-cli own.
 */
export declare class Ssh2DbConnection implements SshConnection {
    private readonly client;
    private readonly stream;
    private readonly protocol;
    private closed;
    private readonly closeListeners;
    private queue;
    private buffer;
    private constructor();
    static open(client: Client, protocol: string, signal?: AbortSignal, timeoutMs?: number): Promise<Ssh2DbConnection>;
    onClose(cb: () => void): void;
    exec(command: string, opts: {
        signal?: AbortSignal;
        timeoutMs: number;
        maxBytes: number;
    }): Promise<ExecResult>;
    readFile(): Promise<FileReadResult>;
    writeFile(): Promise<void>;
    end(signal?: AbortSignal): Promise<void>;
    private onChunk;
    private enqueue;
    private runStatement;
    private waitForPrompt;
}
//# sourceMappingURL=db-session.d.ts.map