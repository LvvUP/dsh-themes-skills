import type { ClientProtocolData } from './types.js';
/** Token fields that may already be known from the create-token response. */
export interface JmsTokenFallback {
    id?: string;
    value?: string;
}
/**
 * Decode `GET /api/v1/authentication/connection-token/{id}/client-url/` into
 * host, port, and token fields used for KoKo SSH.
 */
export declare function parseClientUrlPayload(body: unknown, fallback?: JmsTokenFallback): ClientProtocolData;
/** Decode a `jms://` deep link produced by JumpServer. */
export declare function parseJmsUrl(url: string, fallback?: JmsTokenFallback): ClientProtocolData;
//# sourceMappingURL=jms-url.d.ts.map