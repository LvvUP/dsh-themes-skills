import type { AccountSummary, AssetSummary, ListPage } from './types.js';
/** Pick a stable asset projection from a JumpServer payload. */
export declare function summarizeAsset(raw: unknown): AssetSummary;
/** Pick a stable account projection from a JumpServer payload. */
export declare function summarizeAccount(raw: unknown): AccountSummary;
/**
 * v3.10 / v4.10 put permitted accounts on the user asset detail as
 * `permed_accounts`. There is no `/assets/{id}/accounts/` route on those LTS
 * releases; the admin `/accounts/accounts/` API is a different permission.
 */
export declare function accountsFromAssetPayload(body: unknown): ListPage<AccountSummary> | undefined;
/**
 * JumpServer list APIs return either a DRF page `{count, results}` or a bare array.
 */
export declare function unwrapList<T>(body: unknown, map: (item: unknown) => T): ListPage<T>;
/** Read a JSON-object payload or throw. */
export declare function asRecord(value: unknown): Record<string, unknown>;
//# sourceMappingURL=normalize.d.ts.map