import type { KokoEndpoint } from './types.js';
/**
 * Match Core `handle_endpoint_host`: empty Default host becomes the Core URL host.
 * A configured endpoint host is left unchanged.
 */
export declare function resolveKokoEndpoint(endpoint: KokoEndpoint, coreBaseUrl: string): KokoEndpoint;
/** Hostname only, matching Core stripping the port from request.get_host(). */
export declare function hostnameFromUrl(baseUrl: string): string;
//# sourceMappingURL=koko-endpoint.d.ts.map