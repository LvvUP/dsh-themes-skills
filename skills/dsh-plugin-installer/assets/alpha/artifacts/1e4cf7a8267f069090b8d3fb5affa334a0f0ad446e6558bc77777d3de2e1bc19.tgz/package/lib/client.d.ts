import { type ResolvedAuth } from './types.js';
/** Optional fetch used by tests. */
export type FetchLike = (url: string, init: RequestInit) => Promise<Response>;
/** One Core API request. */
export interface ClientRequest {
    method: string;
    path: string;
    query?: Record<string, string | number | boolean | undefined>;
    body?: unknown;
    signal?: AbortSignal;
    /** HTTP statuses that return the parsed body instead of throwing. */
    allowStatuses?: readonly number[];
}
/** Construct a Core client. Auth and base URL are resolved per request so rotated keys apply immediately. */
export interface JumpServerClientOptions {
    baseUrl: string | (() => string);
    orgId: string | (() => string);
    auth: () => Promise<ResolvedAuth>;
    tlsRejectUnauthorized: boolean;
    fetchImpl?: FetchLike;
    now?: () => Date;
}
/**
 * Join Core base URL with an API path and query string.
 * The returned URL's pathname+search is what Access Key signatures sign.
 */
export declare function buildRequestUrl(baseUrl: string, path: string, query?: Record<string, string | number | boolean | undefined>): URL;
/** Path used as HTTP Signature `(request-target)`: pathname plus query. */
export declare function signingPath(url: URL): string;
/** JumpServer Core REST client. */
export declare class JumpServerClient {
    private readonly baseUrl;
    private readonly orgId;
    private readonly auth;
    private readonly tlsRejectUnauthorized;
    private readonly fetchImpl?;
    private readonly now;
    private insecureTransport?;
    private disposed;
    constructor(options: JumpServerClientOptions);
    private resolveBaseUrl;
    private resolveOrgId;
    /** Perform a JSON API call and throw on unexpected HTTP errors. */
    request<T = unknown>(spec: ClientRequest): Promise<T>;
    /** Perform a JSON API call and return status + body. */
    requestRaw(spec: ClientRequest): Promise<{
        status: number;
        body: unknown;
        path: string;
        text: string;
    }>;
    get<T = unknown>(path: string, query?: Record<string, string | number | boolean | undefined>, signal?: AbortSignal): Promise<T>;
    post<T = unknown>(path: string, body?: unknown, signal?: AbortSignal): Promise<T>;
    patch<T = unknown>(path: string, body?: unknown, signal?: AbortSignal): Promise<T>;
    delete(path: string, signal?: AbortSignal): Promise<void>;
    /** GET that returns undefined on 404 (and any extra `allowStatuses`) instead of throwing. */
    getOrUndefined<T = unknown>(path: string, query?: Record<string, string | number | boolean | undefined>, signal?: AbortSignal, allowStatuses?: readonly number[]): Promise<T | undefined>;
    private fetcher;
    /** Release the undici Agent used when TLS verification is off. */
    dispose(): void;
}
//# sourceMappingURL=client.d.ts.map