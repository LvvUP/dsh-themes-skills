/** Whether a statement only reads data, or changes it. */
export type SqlKind = 'query' | 'write';
/**
 * Classify SQL / Redis / Mongo text. Unknown verbs are writes (fail closed).
 * `WITH` is a query unless a write verb appears later in the statement.
 */
export declare function classifySql(sql: string, protocol?: string): SqlKind;
/** Reject write SQL unless `writeAuthorized` is on. Host sessions are not checked. */
export declare function assertSqlAllowed(sql: string, protocol: string, writeAuthorized: boolean): void;
//# sourceMappingURL=sql-kind.d.ts.map