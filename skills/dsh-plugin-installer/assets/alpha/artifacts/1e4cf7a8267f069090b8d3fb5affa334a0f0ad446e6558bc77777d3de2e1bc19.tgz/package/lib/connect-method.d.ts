/**
 * JumpServer connect_method is not the asset protocol.
 * `ssh` is a protocol; client-url only accepts `ssh_client` / `ssh_guide`.
 */
export declare function nativeConnectMethods(protocol: string): readonly string[];
/** True when Core rejected the token's connect_method during client-url lookup. */
export declare function isUnsupportedConnectMethod(error: unknown): boolean;
//# sourceMappingURL=connect-method.d.ts.map