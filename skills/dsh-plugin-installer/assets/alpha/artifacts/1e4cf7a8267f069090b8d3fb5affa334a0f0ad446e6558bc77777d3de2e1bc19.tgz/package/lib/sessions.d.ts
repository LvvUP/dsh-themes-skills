import { Client } from '#ssh2';
/** Result of one remote command. */
export interface ExecResult {
    exitCode: number | null;
    signal?: string;
    stdout: string;
    stderr: string;
    truncated: boolean;
    timedOut?: boolean;
}
/** Result of one SFTP read. */
export interface FileReadResult {
    path: string;
    content: string;
    encoding: 'utf8' | 'base64';
    truncated: boolean;
    /** Remote file size when SFTP stat succeeds; otherwise the captured byte count. */
    byteLength: number;
    capturedBytes: number;
}
/** Public facts about an open KoKo session. */
export interface SessionInfo {
    session_id: string;
    asset_id: string;
    account: string;
    host: string;
    port: number;
    protocol: string;
    connected_at: string;
    token_id?: string;
}
/** Parameters used to open KoKo SSH. */
export interface OpenSessionInput {
    host: string;
    port: number;
    username: string;
    password: string;
    assetId: string;
    account: string;
    protocol: string;
    tokenId?: string;
    readyTimeoutMs?: number;
}
/** Minimal SSH surface used by the session manager (and tests). */
export interface SshConnection {
    exec(command: string, opts: {
        signal?: AbortSignal;
        timeoutMs: number;
        maxBytes: number;
    }): Promise<ExecResult>;
    readFile(remotePath: string, maxBytes: number, signal?: AbortSignal): Promise<FileReadResult>;
    writeFile(remotePath: string, data: Buffer, signal?: AbortSignal): Promise<void>;
    end(signal?: AbortSignal): Promise<void>;
    onClose(cb: () => void): void;
}
/** Session manager options. */
export interface SessionManagerOptions {
    idleTimeoutMs: number;
    execTimeoutMs: number;
    outputMaxBytes: number;
    writeMaxBytes: number;
    connect?: (input: OpenSessionInput, signal?: AbortSignal) => Promise<SshConnection>;
    /** Called once when a session leaves the map, including idle timeout and unload. */
    onClosed?: (tokenId: string) => void | Promise<void>;
}
/** Holds KoKo SSH sessions for `jms_exec` / SFTP tools. */
export declare class SessionManager {
    private readonly sessions;
    private readonly options;
    private readonly connectFn;
    constructor(options: SessionManagerOptions);
    /** Open a KoKo SSH session and return its public info. */
    open(input: OpenSessionInput, signal?: AbortSignal): Promise<SessionInfo>;
    /** Run a command on an existing session. */
    exec(sessionId: string, command: string, signal?: AbortSignal): Promise<ExecResult & {
        session_id: string;
        command: string;
    }>;
    /** Read a remote file over SFTP. */
    readFile(sessionId: string, remotePath: string, signal?: AbortSignal): Promise<FileReadResult & {
        session_id: string;
    }>;
    /** Write a remote file over SFTP. */
    writeFile(sessionId: string, remotePath: string, content: string, encoding: 'utf8' | 'base64', signal?: AbortSignal): Promise<{
        session_id: string;
        path: string;
        byteLength: number;
    }>;
    /** Close one session. Unknown ids are a no-op. */
    disconnect(sessionId: string, signal?: AbortSignal): Promise<{
        closed: boolean;
        session_id: string;
        token_id?: string;
    }>;
    /** List live sessions. */
    list(): SessionInfo[];
    /** Public facts for one open session. */
    info(sessionId: string): SessionInfo;
    /** Close every session (plugin unload). */
    disposeAll(): Promise<void>;
    /** Run the close hook. Never rejects: a failed token expire must not fail the close. */
    private notifyClosed;
    private require;
    private withBusy;
    private scheduleIdle;
}
/** Open an ssh2 client to KoKo. Database tokens use a PTY; hosts use exec/SFTP. */
export declare function connectSsh2(input: OpenSessionInput, signal?: AbortSignal): Promise<SshConnection>;
export declare class Ssh2Connection implements SshConnection {
    private readonly client;
    private sftp?;
    private sftpPending?;
    private sftpPendingReject?;
    private sftpOpenId;
    private sftpWaiters;
    private closed;
    private readonly closeListeners;
    constructor(client: Client);
    onClose(cb: () => void): void;
    private getSftp;
    private openSftp;
    private awaitSftp;
    private abandonPendingSftp;
    exec(command: string, opts: {
        signal?: AbortSignal;
        timeoutMs: number;
        maxBytes: number;
    }): Promise<ExecResult>;
    readFile(remotePath: string, maxBytes: number, signal?: AbortSignal): Promise<FileReadResult>;
    writeFile(remotePath: string, data: Buffer, signal?: AbortSignal): Promise<void>;
    end(signal?: AbortSignal): Promise<void>;
}
/** Output allowance shared by one command's stdout and stderr. */
export interface ByteBudget {
    remaining: number;
    truncated: boolean;
}
/**
 * Captures a stream's bytes against a shared budget.
 * `cut` is per-buffer so an untouched stream is never clipped on a UTF-8 boundary.
 */
export declare class CappedBuffer {
    private readonly budget;
    private chunks;
    private size;
    private cut;
    constructor(budget: ByteBudget);
    push(chunk: Buffer): void;
    toString(): string;
}
/** Decode bytes; only clip a trailing incomplete code point when the buffer was cut. */
export declare function decodeUtf8Captured(buf: Buffer, truncated: boolean): string;
/** Decode a byte prefix without emitting a replacement char for a cut code point. */
export declare function decodeUtf8Prefix(buf: Buffer): string;
//# sourceMappingURL=sessions.d.ts.map