import type { AccountSummary } from './types.js';
/** Result of mapping a tool account argument onto a Core token account field. */
export interface ResolvedAccountRef {
    account: string;
    inputUsernameRequired: boolean;
}
/**
 * Resolve @USER / @INPUT / UUID without consulting the account list.
 * Empty input throws. Display names and usernames return undefined.
 */
export declare function pickAccountRefDirect(requested: string): ResolvedAccountRef | undefined;
/**
 * Prefer account id, then username. Display names are only used when unique.
 * Unknown strings are passed through so Core aliases still work.
 */
export declare function pickAccountRef(requested: string, accounts: AccountSummary[]): ResolvedAccountRef;
//# sourceMappingURL=account.d.ts.map