import type { Context } from '@deepseek-ai/cordis';
import { type ResolvedConfig } from './config.js';
import { type ResolvedAuth } from './types.js';
/**
 * Resolve JumpServer Access Key credentials for one Core API call.
 * Prefers `ctx.credentials`, then the process environment.
 */
export declare function resolveAuth(ctx: Context, config: ResolvedConfig): Promise<ResolvedAuth>;
/** Read one credential reference without ever logging the value. */
export declare function readSecret(ctx: Context, refName: string): Promise<string | undefined>;
/** Core URL: config wins, then JUMPSERVER_URL. */
export declare function resolveBaseUrl(config: ResolvedConfig): string;
/** Organization UUID: config wins, then JUMPSERVER_ORG_ID, then JumpServer Default org. */
export declare function resolveOrgId(config: ResolvedConfig): string;
/** Asset-admin tools: config wins, then JUMPSERVER_ENABLE_ASSET_ADMIN, then false. */
export declare function resolveEnableAssetAdmin(config: ResolvedConfig): boolean;
/** Database writes: config wins, then JUMPSERVER_ENABLE_DB_WRITE, then false (query only). */
export declare function resolveEnableDbWrite(config: ResolvedConfig): boolean;
/** Parse a .env boolean. Empty or unset is undefined so callers can apply their own default. */
export declare function parseEnvBoolean(value: string | undefined, envName?: string): boolean | undefined;
//# sourceMappingURL=credentials.d.ts.map