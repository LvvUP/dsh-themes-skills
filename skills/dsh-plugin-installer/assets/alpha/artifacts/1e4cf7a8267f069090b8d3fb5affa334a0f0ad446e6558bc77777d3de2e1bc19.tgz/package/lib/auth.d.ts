/** Headers included in JumpServer Access Key signatures, in signing order. */
export declare const ACCESS_KEY_SIGNED_HEADERS: readonly ["(request-target)", "accept", "date"];
/** Inputs for one HMAC-SHA256 HTTP signature. */
export interface AccessKeySignInput {
    /** Access Key ID (`keyId`). */
    keyId: string;
    /** Access Key secret. */
    secret: string;
    /** HTTP method. */
    method: string;
    /** Request path including query string, for example `/api/v1/users/profile/?x=1`. */
    path: string;
    /** Header map used for signing. Keys are matched case-insensitively. */
    headers: Record<string, string>;
}
/**
 * Build the canonical signing string used by JumpServer / HTTP Signatures.
 * Header names in the string are lowercase; the last line has no trailing newline.
 */
export declare function buildSigningString(input: Pick<AccessKeySignInput, 'method' | 'path' | 'headers'>): string;
/**
 * Create a JumpServer `Authorization` header for Access Key authentication.
 *
 * Format:
 * `Signature keyId="...",algorithm="hmac-sha256",headers="(request-target) accept date",signature="..."`
 */
export declare function signAccessKey(input: AccessKeySignInput): string;
/** Format an Instant as HTTP-date (RFC 7231). */
export declare function httpDate(date?: Date): string;
//# sourceMappingURL=auth.d.ts.map