/** Asset protocols KoKo can open as a database session (usql / Redis / Mongo). */
export declare const DATABASE_PROTOCOLS: readonly ["mysql", "mariadb", "postgresql", "oracle", "sqlserver", "clickhouse", "db2", "dameng", "redis", "mongodb"];
/** Map user/asset aliases onto JumpServer protocol names (`mssql` → `sqlserver`). */
export declare function canonicalProtocol(protocol: string): string;
/** True when the asset protocol is a database, not SSH/SFTP. */
export declare function isDatabaseProtocol(protocol: string): boolean;
/** Protocol names from a JumpServer asset `protocols` field. */
export declare function protocolNames(protocols: unknown): string[];
/**
 * Prefer an explicit protocol. Otherwise pick a database protocol from the
 * asset, then ssh, then the first listed protocol.
 */
export declare function pickAssetProtocol(protocols: unknown, requested?: string): string;
/**
 * Choose the token protocol. Uses asset `type` / `category` when `protocols`
 * is empty or uses an alias such as `mssql`.
 */
export declare function pickConnectProtocol(asset: {
    protocols?: unknown;
    type?: string;
    category?: string;
}, requested?: string): string;
//# sourceMappingURL=protocol.d.ts.map