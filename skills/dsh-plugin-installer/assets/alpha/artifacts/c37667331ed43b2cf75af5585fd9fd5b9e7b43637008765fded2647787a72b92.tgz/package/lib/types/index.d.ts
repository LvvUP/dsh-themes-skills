/**
 * Standalone function plugin for DeepSeek Harness.
 * @module @0xsline/dsh-spotlight
 */
/** Cordis plugin name; keep this stable after publishing. */
export declare const name = "dsh-spotlight";
/** Services that must exist before the plugin is applied. */
export declare const inject: string[];
export { Config } from './config.ts';
export { apply } from './runtime.ts';
//# sourceMappingURL=index.d.ts.map