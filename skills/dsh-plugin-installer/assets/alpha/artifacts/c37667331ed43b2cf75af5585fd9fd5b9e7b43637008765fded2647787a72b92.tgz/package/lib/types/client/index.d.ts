/**
 * DSH Web client contribution for `@0xsline/dsh-spotlight`. Loaded
 * through the official client channel: the host scans this package's
 * `dsh.client` declaration and mounts the bundle's named exports as a Cordis
 * plugin. The palette mounts once the host sessions, command-plane, and
 * plugin-inventory services exist — all three are composition-critical in
 * every stock DSH Web deployment, so hard injection cannot fail the boot
 * beyond what the host UI itself already requires. An optional `/spotlight`
 * slash command registers through the host command UI where it exists.
 *
 * Host services are read by name only (narrow local contracts in
 * `src/spotlight/host.ts`).
 * @module @0xsline/dsh-spotlight/client
 */
import type { Context } from 'cordis';
/** Cordis plugin name. */
export declare const name = "dsh-spotlight-client";
/**
 * Services required before the palette mounts. All are provided by the stock
 * DSH Web roster (runtime, api-remotes, ui-commands); the command and
 * inventory Remotes carry inject-guarded descriptors, so the entry must
 * declare them.
 */
export declare const inject: string[];
/**
 * Apply the client plugin: mount the palette and register the `/spotlight`
 * command where the host command UI exists.
 * @param ctx - client root context.
 */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map