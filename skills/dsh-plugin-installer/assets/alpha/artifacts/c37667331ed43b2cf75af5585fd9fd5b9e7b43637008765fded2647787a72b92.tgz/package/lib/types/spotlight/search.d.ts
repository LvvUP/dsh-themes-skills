/** Searchable metadata shared by browser actions. */
export interface SearchCandidate {
    id: string;
    kind: 'action' | 'command' | 'session' | 'plugin';
    title: string;
    detail?: string;
    keywords?: readonly string[];
}
/** One candidate plus its deterministic relevance score. */
export interface RankedCandidate<T extends SearchCandidate> {
    item: T;
    score: number;
}
/** Score a candidate. Negative values mean no match. */
export declare function scoreCandidate(candidate: SearchCandidate, query: string): number;
/**
 * Display cap over an already-ranked list: keep at most `perKind` candidates
 * per kind in rank order. The underlying candidate set stays uncapped, so a
 * query can still surface anything the cap hides in the initial view.
 */
export declare function capPerKind<T extends SearchCandidate>(ranked: readonly RankedCandidate<T>[], perKind: number): RankedCandidate<T>[];
/** Rank matching candidates while preserving discovery order for equal scores. */
export declare function searchCandidates<T extends SearchCandidate>(candidates: readonly T[], query: string, limit?: number): RankedCandidate<T>[];
//# sourceMappingURL=search.d.ts.map