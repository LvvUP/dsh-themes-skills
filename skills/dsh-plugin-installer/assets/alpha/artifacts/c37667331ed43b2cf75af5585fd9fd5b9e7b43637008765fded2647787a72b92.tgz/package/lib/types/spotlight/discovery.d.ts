import type { SearchCandidate } from './search.ts';
import type { SpotlightHost } from './host.ts';
/** A searchable operation backed by a DSH Web host service or the current page. */
export interface SpotlightAction extends SearchCandidate {
    run(): void;
}
/** Open the Web settings surface and switch to the installed-plugins section. */
export declare function openPluginSettings(document: Document): Promise<void>;
/** Discover immediately available actions: built-ins, sessions, and interface elements. */
export declare function discoverVisibleActions(host: SpotlightHost, document: Document): SpotlightAction[];
/** Discover the full action set: visible actions plus the host command and plugin catalogs. */
export declare function discoverActions(host: SpotlightHost, document: Document): Promise<SpotlightAction[]>;
//# sourceMappingURL=discovery.d.ts.map