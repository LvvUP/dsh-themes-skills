/** Keyboard fields used by the global shortcut matcher. */
export interface ShortcutEvent {
    key: string;
    metaKey: boolean;
    ctrlKey: boolean;
    altKey: boolean;
    shiftKey: boolean;
}
/** Persistable exact keyboard shortcut. */
export interface SpotlightShortcut extends ShortcutEvent {
}
/** Platform default: Command-K on Apple devices, Control-K elsewhere. */
export declare function defaultShortcut(applePlatform: boolean): SpotlightShortcut;
/** Admit a user shortcut only when it combines a modifier with a non-modifier key. */
export declare function shortcutFromEvent(event: ShortcutEvent): SpotlightShortcut | undefined;
/** Validate an unknown persisted shortcut. */
export declare function parseShortcut(value: unknown): SpotlightShortcut | undefined;
/** Compact user-facing shortcut label. */
export declare function formatShortcut(shortcut: SpotlightShortcut, applePlatform: boolean): string;
/** Match an exact configured shortcut; without one, retain the legacy Cmd/Ctrl-K matcher. */
export declare function isSpotlightShortcut(event: ShortcutEvent, shortcut?: SpotlightShortcut): boolean;
/** Move a list selection with wraparound. */
export declare function moveSelection(current: number, length: number, delta: -1 | 1): number;
//# sourceMappingURL=keyboard.d.ts.map