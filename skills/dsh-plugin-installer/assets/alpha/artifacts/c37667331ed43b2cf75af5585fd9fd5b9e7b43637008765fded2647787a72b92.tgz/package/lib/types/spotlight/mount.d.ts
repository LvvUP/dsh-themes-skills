import type { SpotlightHost } from './host.ts';
/** Mount the browser contribution and return its disposer plus a programmatic opener. */
export declare function mountSpotlight(host: SpotlightHost, document: Document, window: Window): {
    dispose(): void;
    open(): void;
};
//# sourceMappingURL=mount.d.ts.map