/**
 * The hand-written Typert HOST manifest for `dsh-mcp-panel`, exported as
 * `./typert` so the harness's typert-loader registers the `mcpPanel` status
 * and probe invocations automatically when this plugin mounts. Same shape as
 * a generator output (validated by the loader): package face, empty model and
 * schemas, and the canonical invocation list shared with the client Remote
 * contribution (`src/wire.ts`).
 *
 * @module dsh-mcp-panel/typert
 */
/** Host Typert manifest (validated by `@deepseek-ai/dsh-typert-loader`). */
export declare const TYPERT: Readonly<{
    package: "dsh-mcp-panel";
    face: "host";
    schemas: readonly never[];
    invocations: readonly (Readonly<{
        readonly id: 'dsh-mcp-panel#mcpPanel/status';
        readonly service: 'mcpPanel';
        readonly namespace: 'mcpPanel';
        readonly method: 'status';
        readonly invocation: Readonly<{
            kind: "direct";
        }>;
        readonly parameters: readonly never[];
        readonly result: Readonly<{
            mode: "strict";
            typeSymbol: "dsh-mcp-panel/types#McpPanelSnapshot";
            schema: import("zod").ZodObject<{
                observed: import("zod").ZodBoolean;
                patchFile: import("zod").ZodNullable<import("zod").ZodString>;
                refreshIntervalMs: import("zod").ZodNumber;
                servers: import("zod").ZodArray<import("zod").ZodObject<{
                    serverName: import("zod").ZodString;
                    entryId: import("zod").ZodString;
                    transport: import("zod").ZodUnion<readonly [import("zod").ZodLiteral<"stdio">, import("zod").ZodLiteral<"streamable-http">, import("zod").ZodLiteral<"unknown">]>;
                    target: import("zod").ZodString;
                    enabled: import("zod").ZodBoolean;
                    fiberPhase: import("zod").ZodUnion<readonly [import("zod").ZodLiteral<"pending">, import("zod").ZodLiteral<"loading">, import("zod").ZodLiteral<"active">, import("zod").ZodLiteral<"failed">, import("zod").ZodLiteral<"unloading">, import("zod").ZodNull]>;
                    configuredNote: import("zod").ZodNullable<import("zod").ZodString>;
                    toolCount: import("zod").ZodNumber;
                    tools: import("zod").ZodArray<import("zod").ZodObject<{
                        name: import("zod").ZodString;
                        description: import("zod").ZodString;
                    }, import("zod/v4/core").$strip>>;
                    phase: import("zod").ZodUnion<readonly [import("zod").ZodLiteral<"connecting">, import("zod").ZodLiteral<"connected">, import("zod").ZodLiteral<"waiting">, import("zod").ZodLiteral<"exhausted">, import("zod").ZodLiteral<"disposed">, import("zod").ZodLiteral<"unknown">]>;
                    attempt: import("zod").ZodNumber;
                    maxAttempts: import("zod").ZodNumber;
                    delayMs: import("zod").ZodNullable<import("zod").ZodNumber>;
                    reconnectCount: import("zod").ZodNumber;
                    lastError: import("zod").ZodNullable<import("zod").ZodString>;
                    connectedAt: import("zod").ZodNullable<import("zod").ZodNumber>;
                    observedAt: import("zod").ZodNullable<import("zod").ZodNumber>;
                    probeState: import("zod").ZodUnion<readonly [import("zod").ZodLiteral<"reachable">, import("zod").ZodLiteral<"unreachable">, import("zod").ZodNull]>;
                    probeCheckedAt: import("zod").ZodNullable<import("zod").ZodNumber>;
                    statusSource: import("zod").ZodUnion<readonly [import("zod").ZodLiteral<"upstream-event">, import("zod").ZodLiteral<"derived">]>;
                    config: import("zod").ZodNullable<import("zod").ZodObject<{
                        serverName: import("zod").ZodString;
                        transport: import("zod").ZodUnion<readonly [import("zod").ZodLiteral<"stdio">, import("zod").ZodLiteral<"streamable-http">, import("zod").ZodLiteral<"unknown">]>;
                        command: import("zod").ZodNullable<import("zod").ZodString>;
                        args: import("zod").ZodArray<import("zod").ZodString>;
                        cwd: import("zod").ZodNullable<import("zod").ZodString>;
                        url: import("zod").ZodNullable<import("zod").ZodString>;
                        envKeys: import("zod").ZodArray<import("zod").ZodString>;
                        headerKeys: import("zod").ZodArray<import("zod").ZodString>;
                        toolCallTimeoutMs: import("zod").ZodNullable<import("zod").ZodNumber>;
                        failOnStartupError: import("zod").ZodNullable<import("zod").ZodBoolean>;
                        reconnectEnabled: import("zod").ZodNullable<import("zod").ZodBoolean>;
                        reconnectMaxAttempts: import("zod").ZodNullable<import("zod").ZodNumber>;
                    }, import("zod/v4/core").$strip>>;
                    diagnostics: import("zod").ZodArray<import("zod").ZodObject<{
                        code: import("zod").ZodString;
                        text: import("zod").ZodString;
                    }, import("zod/v4/core").$strip>>;
                    exitCode: import("zod").ZodNullable<import("zod").ZodNumber>;
                    stderrTail: import("zod").ZodNullable<import("zod").ZodString>;
                }, import("zod/v4/core").$strip>>;
                probes: import("zod").ZodArray<import("zod").ZodObject<{
                    id: import("zod").ZodString;
                    serverName: import("zod").ZodString;
                    status: import("zod").ZodUnion<readonly [import("zod").ZodLiteral<"running">, import("zod").ZodLiteral<"stopping">, import("zod").ZodLiteral<"completed">, import("zod").ZodLiteral<"killed">, import("zod").ZodLiteral<"failed">, import("zod").ZodLiteral<"unknown">]>;
                    startedAt: import("zod").ZodNumber;
                    finishedAt: import("zod").ZodNullable<import("zod").ZodNumber>;
                    detail: import("zod").ZodNullable<import("zod").ZodString>;
                }, import("zod/v4/core").$strip>>;
                capabilities: import("zod").ZodObject<{
                    resources: import("zod").ZodObject<{
                        available: import("zod").ZodBoolean;
                    }, import("zod/v4/core").$strip>;
                    prompts: import("zod").ZodObject<{
                        available: import("zod").ZodBoolean;
                    }, import("zod/v4/core").$strip>;
                }, import("zod/v4/core").$strip>;
                trial: import("zod").ZodObject<{
                    enabled: import("zod").ZodBoolean;
                    timeoutMs: import("zod").ZodNumber;
                    maxResultChars: import("zod").ZodNumber;
                }, import("zod/v4/core").$strip>;
                writeEnabled: import("zod").ZodBoolean;
                catalog: import("zod").ZodArray<import("zod").ZodObject<{
                    id: import("zod").ZodString;
                    name: import("zod").ZodString;
                    description: import("zod").ZodString;
                    transport: import("zod").ZodUnion<readonly [import("zod").ZodLiteral<"stdio">, import("zod").ZodLiteral<"streamable-http">]>;
                    command: import("zod").ZodOptional<import("zod").ZodString>;
                    args: import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodString>>;
                    url: import("zod").ZodOptional<import("zod").ZodString>;
                    envKeys: import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodString>>;
                    headerKeys: import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodString>>;
                    tags: import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodString>>;
                }, import("zod/v4/core").$strip>>;
            }, import("zod/v4/core").$strip>;
        }>;
        readonly sourceLocation: Readonly<{
            file: "src/wire.ts";
            line: 1;
            column: 1;
        }>;
    }> | Readonly<{
        readonly id: 'dsh-mcp-panel#mcpPanel/probe';
        readonly service: 'mcpPanel';
        readonly namespace: 'mcpPanel';
        readonly method: 'probe';
        readonly invocation: Readonly<{
            kind: "direct";
        }>;
        readonly parameters: readonly Readonly<{
            name: string;
            wire: string;
            source: "json";
            codec: Readonly<{
                mode: "strict";
                typeSymbol: "dsh-mcp-panel/types#ProbeRequestServerName";
                schema: import("zod").ZodString;
            }>;
        }>[];
        readonly result: Readonly<{
            mode: "strict";
            typeSymbol: "dsh-mcp-panel/types#ProbeStarted";
            schema: import("zod").ZodObject<{
                jobId: import("zod").ZodString;
                note: import("zod").ZodString;
            }, import("zod/v4/core").$strip>;
        }>;
        readonly sourceLocation: Readonly<{
            file: "src/wire.ts";
            line: 1;
            column: 1;
        }>;
    }> | Readonly<{
        readonly id: 'dsh-mcp-panel#mcpPanel/previewPatch';
        readonly service: 'mcpPanel';
        readonly namespace: 'mcpPanel';
        readonly method: 'previewPatch';
        readonly invocation: Readonly<{
            kind: "direct";
        }>;
        readonly parameters: readonly Readonly<{
            name: string;
            wire: string;
            source: "json";
            codec: Readonly<{
                mode: "strict";
                typeSymbol: "dsh-mcp-panel/types#PatchOpJson";
                schema: import("zod").ZodString;
            }>;
        }>[];
        readonly result: Readonly<{
            mode: "strict";
            typeSymbol: "dsh-mcp-panel/types#PatchPreview";
            schema: import("zod").ZodObject<{
                fragment: import("zod").ZodString;
                file: import("zod").ZodNullable<import("zod").ZodString>;
                ops: import("zod").ZodNumber;
            }, import("zod/v4/core").$strip>;
        }>;
        readonly sourceLocation: Readonly<{
            file: "src/wire.ts";
            line: 1;
            column: 1;
        }>;
    }> | Readonly<{
        readonly id: 'dsh-mcp-panel#mcpPanel/writePatch';
        readonly service: 'mcpPanel';
        readonly namespace: 'mcpPanel';
        readonly method: 'writePatch';
        readonly invocation: Readonly<{
            kind: "direct";
        }>;
        readonly parameters: readonly (Readonly<{
            name: string;
            wire: string;
            source: "json";
            codec: Readonly<{
                mode: "strict";
                typeSymbol: "dsh-mcp-panel/types#PatchOpJson";
                schema: import("zod").ZodString;
            }>;
        }> | Readonly<{
            name: string;
            wire: string;
            source: "json";
            codec: Readonly<{
                mode: "strict";
                typeSymbol: "dsh-mcp-panel/types#PatchWriteConfirmed";
                schema: import("zod").ZodBoolean;
            }>;
        }> | Readonly<{
            name: string;
            wire: string;
            source: "json";
            codec: Readonly<{
                mode: "strict";
                typeSymbol: "dsh-mcp-panel/types#PatchWriteSessionId";
                schema: import("zod").ZodString;
            }>;
            acceptsUndefined: true;
        }>)[];
        readonly result: Readonly<{
            mode: "strict";
            typeSymbol: "dsh-mcp-panel/types#PatchWriteResult";
            schema: import("zod").ZodObject<{
                file: import("zod").ZodString;
                backupPath: import("zod").ZodString;
                approvalPath: import("zod").ZodUnion<readonly [import("zod").ZodLiteral<"harness-approval">, import("zod").ZodLiteral<"interactive-confirmation">]>;
                bytes: import("zod").ZodNumber;
                ops: import("zod").ZodNumber;
                note: import("zod").ZodString;
            }, import("zod/v4/core").$strip>;
        }>;
        readonly sourceLocation: Readonly<{
            file: "src/wire.ts";
            line: 1;
            column: 1;
        }>;
    }> | Readonly<{
        readonly id: 'dsh-mcp-panel#mcpPanel/callTool';
        readonly service: 'mcpPanel';
        readonly namespace: 'mcpPanel';
        readonly method: 'callTool';
        readonly invocation: Readonly<{
            kind: "direct";
        }>;
        readonly parameters: readonly (Readonly<{
            name: string;
            wire: string;
            source: "json";
            codec: Readonly<{
                mode: "strict";
                typeSymbol: "dsh-mcp-panel/types#TrialRequestJson";
                schema: import("zod").ZodString;
            }>;
        }> | Readonly<{
            name: string;
            wire: string;
            source: "json";
            codec: Readonly<{
                mode: "strict";
                typeSymbol: "dsh-mcp-panel/types#TrialSessionId";
                schema: import("zod").ZodString;
            }>;
            acceptsUndefined: true;
        }>)[];
        readonly result: Readonly<{
            mode: "strict";
            typeSymbol: "dsh-mcp-panel/types#McpTrialResultWire";
            schema: import("zod").ZodObject<{
                callId: import("zod").ZodString;
                isError: import("zod").ZodBoolean;
                truncated: import("zod").ZodBoolean;
                durationMs: import("zod").ZodNumber;
                resultJson: import("zod").ZodString;
            }, import("zod/v4/core").$strip>;
        }>;
        readonly sourceLocation: Readonly<{
            file: "src/wire.ts";
            line: 1;
            column: 1;
        }>;
    }>)[];
    model: Readonly<{
        services: readonly never[];
        events: readonly never[];
        objects: readonly never[];
    }>;
}>;
//# sourceMappingURL=typert.host.d.ts.map