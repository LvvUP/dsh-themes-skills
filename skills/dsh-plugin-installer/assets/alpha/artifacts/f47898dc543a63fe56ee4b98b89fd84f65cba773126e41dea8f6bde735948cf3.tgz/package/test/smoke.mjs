/**
 * Smoke test for dsh-tiered-approval (rules + LLM reviewer + perMode preset-following).
 *
 * Drives apply() with a fake ctx (fake `llm` service returning canned verdicts,
 * fake `sandboxPolicy`) and asserts gate stamping, reviewer routing, the
 * approval answerer, and perMode behavior.
 *
 * Run it where the real @deepseek-ai/* packages resolve (e.g. inside a DSH
 * profile, or with the packages linked):
 *
 *   node test/smoke.mjs     # expect "ALL PASS"
 */
import { name, Config, apply } from "../lib/index.js";

let failures = 0;
function check(label, actual, expected) {
  const ok = Object.is(actual, expected);
  if (!ok) failures++;
  console.log(`${ok ? "PASS" : "FAIL"}  ${label}${ok ? "" : `  (got ${JSON.stringify(actual)}, want ${JSON.stringify(expected)})`}`);
}

function textStream(text) {
  return (async function* () {
    yield { type: "block-start", index: 0, blockType: "text" };
    yield { type: "text-delta", index: 0, text };
    yield { type: "block-end", index: 0, block: { type: "text", text } };
    yield { type: "usage", usage: { inputTokens: 1, outputTokens: 1, totalTokens: 2 } };
    yield { type: "finish", reason: { kind: "stop" } };
  })();
}

function makeCtx({ llmStream, verdictMode = "allow", sandboxMode = "workspace-write" }) {
  let streamCalls = 0;
  const lastOptions = [];
  const llm = {
    listProviders: () => [{ id: "test-provider", name: "Test" }],
    listModels: async () => [{ id: "test-model", provider: "test-provider" }],
    stream(options) {
      streamCalls++;
      lastOptions.push(options);
      if (llmStream === "throw") throw new Error("provider exploded");
      return textStream(JSON.stringify({ verdict: verdictMode, reason: "unit test" }));
    }
  };
  const listeners = {};
  const listenerOpts = {};
  const guards = [];
  const commandDefs = [];
  const services = {
    llm,
    sandboxPolicy: {
      resolve: () => ({ mode: sandboxMode, workspaceRoot: "C:\\ws" })
    },
    commands: {
      register(def) {
        commandDefs.push(def);
      }
    }
  };
  const ctx = {
    logger: {
      info: (...a) => console.log("     [log]", a.join(" ")),
      warn: (...a) => console.log("     [warn]", a.join(" "))
    },
    on(event, fn, opts) {
      (listeners[event] ??= []).push(fn);
      listenerOpts[event] = opts;
    },
    get(name) {
      return services[name];
    },
    tools: {
      guard(fn) {
        guards.push(fn);
      }
    }
  };
  return { ctx, listeners, listenerOpts, streamCalls: () => streamCalls, guards, commandDefs, lastOptions: () => lastOptions };
}

const baseConfig = {
  builtinDeny: true,
  deny: [],
  allow: [],
  answerer: { allowModes: ["workspace-write"], allowJustifications: [], denyJustifications: [] },
  review: { mode: "on", skipTools: [], skipNested: true, allowModes: ["workspace-write", "danger-full-access"], onUncertain: "ask", perMode: {}, timeoutMs: 20000, maxTokens: 512, maxInputChars: 12000 },
  log: true
};

async function gate(pre, exec_) {
  let nexted = false;
  const decision = await pre(exec_, async () => {
    nexted = true;
    return { kind: "allow" };
  });
  return { decision, nexted };
}

async function answer(ask, req) {
  let delegated = false;
  const outcome = await ask(req, async () => {
    delegated = true;
    return "human";
  });
  return { outcome, delegated };
}

const exec = (name_, callId, args, parent) => ({ name: name_, callId, arguments: args, ...parent ? { parent } : {} });

// ════════════════════════════════════════════════════════════════════════════
console.log("── tier 0: static rules still win ──");
{
  const { ctx, listeners, streamCalls } = makeCtx({});
  apply(ctx, baseConfig);
  const { decision, nexted } = await gate(listeners["tools/pre-execute"][0], exec("pwsh", "c1", {
    command: "Remove-Item C:\\Users\\x -Recurse -Force",
    sandbox_permissions: "danger-full-access",
    justification: "clean"
  }));
  check("static deny beats reviewer", decision.kind, "deny");
  check("no reviewer call on static deny", streamCalls(), 0);
  check("not delegated", nexted, false);
}

// ════════════════════════════════════════════════════════════════════════════
console.log("── reviewer allow / deny / ask / failure ──");
{
  const { ctx, listeners, streamCalls } = makeCtx({ verdictMode: "allow" });
  apply(ctx, baseConfig);
  const pre = listeners["tools/pre-execute"][0];
  const ask = listeners["approval/request"][0];

  const r1 = await gate(pre, exec("pwsh", "c2", { command: "npm install" }));
  check("reviewer allow: gate proceeds", r1.decision.kind, "allow");
  check("reviewer called once", streamCalls(), 1);

  const r2 = await answer(ask, { toolName: "pwsh", callId: "c2", reason: "escalate sandbox to danger-full-access: install deps" });
  check("review-allow dfa auto-approved (default review.allowModes)", r2.outcome, "allowed-once");
}
{
  const denied = makeCtx({ verdictMode: "deny" });
  apply(denied.ctx, baseConfig);
  const d = await gate(denied.listeners["tools/pre-execute"][0], exec("pwsh", "c3", { command: "npm install" }));
  check("reviewer deny: gate denies", d.decision.kind, "deny");
}
{
  const asked = makeCtx({ verdictMode: "ask" });
  apply(asked.ctx, baseConfig);
  const a1 = await gate(asked.listeners["tools/pre-execute"][0], exec("pwsh", "c4", { command: "npm install" }));
  check("reviewer ask (non-escalation): gate asks", a1.decision.kind, "ask");
  const a2 = await gate(asked.listeners["tools/pre-execute"][0], exec("pwsh", "c5", {
    command: "npm install", sandbox_permissions: "danger-full-access", justification: "x"
  }));
  check("reviewer ask (escalation): gate proceeds (body asks once)", a2.decision.kind, "allow");
}
{
  const broke = makeCtx({ llmStream: "throw" });
  apply(broke.ctx, baseConfig);
  const f = await gate(broke.listeners["tools/pre-execute"][0], exec("pwsh", "c6", { command: "npm install" }));
  check("reviewer failure: silent fallback", f.decision.kind, "allow");
}

// ════════════════════════════════════════════════════════════════════════════
console.log("── perMode: Full access reviews everything by default ──");
{
  // danger-full-access with default (uncustomized) global skipTools → even read is reviewed
  const dfa = makeCtx({ sandboxMode: "danger-full-access" });
  apply(dfa.ctx, baseConfig);
  const g = await gate(dfa.listeners["tools/pre-execute"][0], exec("read", "c7", { file_path: "a.txt" }));
  check("dfa default: read is reviewed", g.decision.kind, "allow");
  check("dfa default: reviewer called for read", dfa.streamCalls(), 1);
}
{
  // customized global skipTools → dfa follows global (read skipped)
  const cfg = JSON.parse(JSON.stringify(baseConfig));
  cfg.review.skipTools = ["read"];
  const dfa2 = makeCtx({ sandboxMode: "danger-full-access" });
  apply(dfa2.ctx, cfg);
  await gate(dfa2.listeners["tools/pre-execute"][0], exec("read", "c8", { file_path: "a.txt" }));
  check("dfa with customized global skipTools: read skipped", dfa2.streamCalls(), 0);
}
{
  // explicit perMode['danger-full-access'].skipTools override
  const cfg = JSON.parse(JSON.stringify(baseConfig));
  cfg.review.perMode = { "danger-full-access": { skipTools: ["read"] } };
  const dfa3 = makeCtx({ sandboxMode: "danger-full-access" });
  apply(dfa3.ctx, cfg);
  await gate(dfa3.listeners["tools/pre-execute"][0], exec("read", "c9", { file_path: "a.txt" }));
  check("perMode dfa skipTools override: read skipped", dfa3.streamCalls(), 0);
}

// ════════════════════════════════════════════════════════════════════════════
console.log("── perMode: per-mode off / narrowed allowModes ──");
{
  const cfg = JSON.parse(JSON.stringify(baseConfig));
  cfg.review.perMode = { "workspace-write": { mode: "off" } };
  const off = makeCtx({ sandboxMode: "workspace-write" });
  apply(off.ctx, cfg);
  await gate(off.listeners["tools/pre-execute"][0], exec("pwsh", "c10", { command: "npm install" }));
  check("perMode workspace-write mode off: no reviewer call", off.streamCalls(), 0);
}
{
  const cfg = JSON.parse(JSON.stringify(baseConfig));
  cfg.review.perMode = { "workspace-write": { allowModes: ["workspace-write"] } };
  const { ctx, listeners } = makeCtx({ verdictMode: "allow", sandboxMode: "workspace-write" });
  apply(ctx, cfg);
  const pre = listeners["tools/pre-execute"][0];
  const ask = listeners["approval/request"][0];
  await gate(pre, exec("pwsh", "c11", { command: "npm install", sandbox_permissions: "danger-full-access", justification: "x" }));
  const r = await answer(ask, { toolName: "pwsh", callId: "c11", reason: "escalate sandbox to danger-full-access: install" });
  check("perMode workspace-write allowModes narrowed: dfa escalation to human", r.outcome, "human");
}
{
  // other modes are unaffected by that perMode entry (read-only still uses the global allowModes)
  const cfg = JSON.parse(JSON.stringify(baseConfig));
  cfg.review.perMode = { "workspace-write": { allowModes: ["workspace-write"] } };
  const { ctx, listeners } = makeCtx({ verdictMode: "allow", sandboxMode: "read-only" });
  apply(ctx, cfg);
  const pre = listeners["tools/pre-execute"][0];
  const ask = listeners["approval/request"][0];
  await gate(pre, exec("pwsh", "c12", { command: "npm install", sandbox_permissions: "danger-full-access", justification: "x" }));
  const r = await answer(ask, { toolName: "pwsh", callId: "c12", reason: "escalate sandbox to danger-full-access: install" });
  check("read-only mode: global review.allowModes still applies (dfa auto-approved)", r.outcome, "allowed-once");
}

// ════════════════════════════════════════════════════════════════════════════
console.log("── rule-based answerer regression ──");
{
  const { ctx, listeners } = makeCtx({});
  const cfg = JSON.parse(JSON.stringify(baseConfig));
  cfg.answerer.denyJustifications = ["drop\\s+database"];
  cfg.allow = [{ tool: "pwsh", where: { command: ["pnpm\\s+install"] }, escalating: true }];
  apply(ctx, cfg);
  const pre = listeners["tools/pre-execute"][0];
  const ask = listeners["approval/request"][0];
  await gate(pre, exec("pwsh", "c13", { command: "pnpm install", sandbox_permissions: "workspace-write", justification: "install" }));
  const ok = await answer(ask, { toolName: "pwsh", callId: "c13", reason: "escalate sandbox to workspace-write: install deps" });
  check("rules allow-stamp still auto-approves", ok.outcome, "allowed-once");
  const no = await answer(ask, { toolName: "pwsh", callId: "c14", reason: "escalate sandbox to workspace-write: drop database prod" });
  check("denyJustifications still rejects", no.outcome, "rejected");
  const uh = await answer(ask, { toolName: "web_fetch", callId: "c15", reason: "fetch https://example.com" });
  check("unmatched ask still delegates to human", uh.outcome, "human");
}

// ════════════════════════════════════════════════════════════════════════════
console.log("── builtinDenyRules 可配置 + 正则加载期校验 ──");
{
  // builtinDenyRules: [] 关掉内置模式 → 升权破坏性命令不再被静态层拦截（交给审查员）
  const cfg = JSON.parse(JSON.stringify(baseConfig));
  cfg.builtinDenyRules = [];
  const { ctx, listeners } = makeCtx({ verdictMode: "allow" });
  apply(ctx, cfg);
  const g = await gate(listeners["tools/pre-execute"][0], exec("pwsh", "c16", {
    command: "Remove-Item C:\\Users\\x -Recurse -Force",
    sandbox_permissions: "danger-full-access",
    justification: "clean"
  }));
  check("builtinDenyRules [] disables built-in net (gate proceeds)", g.decision.kind, "allow");
}
{
  // 自定义内置规则：通过 builtinDenyRules 追加模式
  const cfg = JSON.parse(JSON.stringify(baseConfig));
  cfg.builtinDenyRules = [{ tool: "pwsh", escalating: true, where: { command: ["custom-danger"] }, reason: "custom rule" }];
  const { ctx, listeners } = makeCtx({});
  apply(ctx, cfg);
  const g = await gate(listeners["tools/pre-execute"][0], exec("pwsh", "c17", {
    command: "do custom-danger thing",
    sandbox_permissions: "danger-full-access",
    justification: "x"
  }));
  check("custom builtinDenyRules pattern denies", g.decision.kind, "deny");
  check("custom reason surfaced", g.decision.reason, "custom rule");
}
{
  // 无效正则 → apply 抛错（fail loud）
  const bad = JSON.parse(JSON.stringify(baseConfig));
  bad.deny = [{ tool: "pwsh", where: { command: ["([unclosed"] } }];
  let threw = false;
  try {
    apply(makeCtx({}).ctx, bad);
  } catch {
    threw = true;
  }
  check("invalid deny regex fails loud at apply", threw, true);

  const bad2 = JSON.parse(JSON.stringify(baseConfig));
  bad2.answerer.denyJustifications = ["([unclosed"];
  let threw2 = false;
  try {
    apply(makeCtx({}).ctx, bad2);
  } catch {
    threw2 = true;
  }
  check("invalid answerer regex fails loud at apply", threw2, true);
}

// ════════════════════════════════════════════════════════════════════════════
console.log("── 学自 Andy8647：self-kill 守卫 / guard 双保险 / 上下文审查 / onUncertain ──");
{
  // self-kill 守卫：进程终止命令（无升权也拒绝）
  const { ctx, listeners } = makeCtx({});
  apply(ctx, baseConfig);
  const d = await gate(listeners["tools/pre-execute"][0], exec("pwsh", "c18", { command: "Stop-Process -Id 999" }));
  check("self-kill guard denies Stop-Process", d.decision.kind, "deny");
  const d2 = await gate(listeners["tools/pre-execute"][0], exec("pwsh", "c19", { command: "taskkill /F /IM node.exe" }));
  check("self-kill guard denies taskkill", d2.decision.kind, "deny");
  const ok2 = await gate(listeners["tools/pre-execute"][0], exec("pwsh", "c20", { command: "kill 1234" }));
  check("escape hatch: plain kill <pid> not denied by static tier", ok2.decision.kind, "allow");
}
{
  // guard 双保险：ctx.tools.guard 已注册，且对静态 deny 返回理由
  const { ctx, guards } = makeCtx({});
  apply(ctx, baseConfig);
  check("tools.guard registered", guards.length, 1);
  const reason = guards[0]({ name: "pwsh", callId: "g1", arguments: {
    command: "Remove-Item C:\\Users\\x -Recurse -Force",
    sandbox_permissions: "danger-full-access",
    justification: "x"
  } });
  check("guard denies destructive escalated call", typeof reason, "string");
  const pass = guards[0]({ name: "pwsh", callId: "g2", arguments: { command: "npm install" } });
  check("guard passes benign call", pass, undefined);
}
{
  // 上下文感知审查员：输入帧包含最近一条真人消息
  const { ctx, listeners, lastOptions } = makeCtx({});
  apply(ctx, baseConfig);
  await gate(listeners["tools/pre-execute"][0], {
    name: "pwsh", callId: "c21", arguments: { command: "npm install" },
    agent: { session: { events: [
      { type: "user/message", data: { source: { kind: "plugin" }, content: [{ type: "text", text: "skill injected noise" }] } },
      { type: "user/message", data: { source: { kind: "user" }, content: [{ type: "text", text: "please install the dependencies" }] } }
    ] } }
  });
  const frame = lastOptions()[0]?.messages?.[0]?.content?.[0]?.text ?? "";
  check("reviewer frame includes userMessage", frame.includes("please install the dependencies"), true);
  check("reviewer frame skips injected (plugin) messages", frame.includes("skill injected noise"), false);
}
{
  // onUncertain: 'deny' → 审查失败 fail-closed 拒绝
  const cfg = JSON.parse(JSON.stringify(baseConfig));
  cfg.review.onUncertain = "deny";
  const broke = makeCtx({ llmStream: "throw" });
  apply(broke.ctx, cfg);
  const f = await gate(broke.listeners["tools/pre-execute"][0], exec("pwsh", "c22", { command: "npm install" }));
  check("onUncertain deny: reviewer failure denies", f.decision.kind, "deny");
  check("onUncertain deny: fail-closed reason", f.decision.reason, "auto-review: classifier unavailable; call denied (fail-closed)");
}
{
  // onUncertain: 'deny' → 审查员 ask 也变成拒绝
  const cfg = JSON.parse(JSON.stringify(baseConfig));
  cfg.review.onUncertain = "deny";
  const asked = makeCtx({ verdictMode: "ask" });
  apply(asked.ctx, cfg);
  const a = await gate(asked.listeners["tools/pre-execute"][0], exec("pwsh", "c23", { command: "npm install" }));
  check("onUncertain deny: reviewer ask becomes deny", a.decision.kind, "deny");
}
{
  // onUncertain 默认 'ask'：审查失败仍静默回退（回归）
  const broke = makeCtx({ llmStream: "throw" });
  apply(broke.ctx, baseConfig);
  const f = await gate(broke.listeners["tools/pre-execute"][0], exec("pwsh", "c24", { command: "npm install" }));
  check("onUncertain ask (default): failure still silent fallback", f.decision.kind, "allow");
}

// ════════════════════════════════════════════════════════════════════════════
console.log("── /auto-review 快捷开关 ──");
{
  const { ctx, listeners, commandDefs, streamCalls } = makeCtx({ verdictMode: "ask" });
  apply(ctx, baseConfig);
  const cmd = commandDefs.find((d) => d.name === "auto-review");
  check("command registered", typeof cmd, "object");
  check("command has input hint", cmd.input?.hint, "on | off | rules | tiered | auto | status | reset");
  const agent = { session: { events: [] } };

  // 默认（tiered）：审查员 ask → 交人工
  const s0 = cmd.handler({ rawInput: "status", agent });
  check("status default tier = tiered", s0.text.includes("当前档位：tiered"), true);

  // auto → 两态自主：审查员 ask 变 deny
  cmd.handler({ rawInput: "auto", agent });
  const a = await gate(listeners["tools/pre-execute"][0], exec("pwsh", "c25", { command: "npm install" }));
  check("switch auto: reviewer ask becomes deny", a.decision.kind, "deny");

  // tiered → 回到三态：审查员 ask 交人工
  cmd.handler({ rawInput: "tiered", agent });
  const b = await gate(listeners["tools/pre-execute"][0], exec("pwsh", "c26", { command: "npm install" }));
  check("switch tiered: reviewer ask goes to human", b.decision.kind, "ask");

  // off → 纯规则：不再调审查员
  cmd.handler({ rawInput: "off", agent });
  const calls = streamCalls();
  await gate(listeners["tools/pre-execute"][0], exec("pwsh", "c27", { command: "npm install" }));
  check("switch off: no reviewer call", streamCalls(), calls);

  // status 显示开关覆盖
  const s1 = cmd.handler({ rawInput: "status", agent });
  check("status shows override note", s1.text.includes("开关覆盖中"), true);

  // reset → 回到配置默认
  cmd.handler({ rawInput: "reset", agent });
  const s2 = cmd.handler({ rawInput: "status", agent });
  check("status after reset shows config-driven", s2.text.includes("跟随配置"), true);
}
{
  // 计数：一次静态 deny 计入 counters（经 status 可见）
  const { ctx, listeners, commandDefs } = makeCtx({});
  apply(ctx, baseConfig);
  await gate(listeners["tools/pre-execute"][0], exec("pwsh", "c28", {
    command: "Remove-Item C:\\Users\\x -Recurse -Force",
    sandbox_permissions: "danger-full-access",
    justification: "x"
  }));
  const cmd = commandDefs.find((d) => d.name === "auto-review");
  const s = cmd.handler({ rawInput: "status", agent: { session: { events: [] } } });
  check("status shows deny counter", s.text.includes("deny=1"), true);
  check("status shows recent decision", s.text.includes("escalated destructive"), true);
}

// ════════════════════════════════════════════════════════════════════════════
console.log("── config defaults & listener registration ──");
{
  const { ctx, listeners, listenerOpts } = makeCtx({});
  apply(ctx, baseConfig);
  check("listeners: pre-execute", typeof listeners["tools/pre-execute"]?.[0], "function");
  check("listeners: result", typeof listeners["tools/result"]?.[0], "function");
  check("listeners: approval", typeof listeners["approval/request"]?.[0], "function");
  check("pre-execute prepend", listenerOpts["tools/pre-execute"]?.prepend, true);
  check("approval prepend (ahead of host terminal answerer)", listenerOpts["approval/request"]?.prepend, true);

  const parsed = Config({});
  check("Config default review.mode", parsed.review.mode, "on");
  check("Config default review.perMode is object", typeof parsed.review.perMode, "object");
  check("Config default review.allowModes[0]", parsed.review.allowModes[0], "workspace-write");
  check("Config default review.onUncertain", parsed.review.onUncertain, "ask");
  check("Config default answerer.allowModes[0]", parsed.answerer.allowModes[0], "workspace-write");
  check("Config default builtinDeny", parsed.builtinDeny, true);
  check("Config default builtinDenyRules is non-empty", Array.isArray(parsed.builtinDenyRules) && parsed.builtinDenyRules.length > 0, true);
  const withPer = Config({ review: { perMode: { "danger-full-access": { mode: "off" } } } });
  check("Config parses perMode override", withPer.review.perMode["danger-full-access"].mode, "off");
}

console.log(failures === 0 ? "\nALL PASS" : `\n${failures} FAILURES`);
process.exit(failures === 0 ? 0 : 1);
