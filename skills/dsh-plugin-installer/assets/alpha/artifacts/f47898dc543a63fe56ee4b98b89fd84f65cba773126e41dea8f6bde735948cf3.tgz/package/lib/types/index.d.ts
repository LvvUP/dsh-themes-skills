/**
 * dsh-auto-approval type surface.
 * @module dsh-auto-approval
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';

/**
 * One deny/allow rule: match a tool call by name and argument patterns.
 * All fields except `tool` are optional and default at runtime.
 */
export interface Rule {
  /** Tool name to match, or `*` for every tool. */
  tool: string;
  /**
   * Argument matchers: each key is a dotted path into the call arguments
   * (e.g. `command`, `file_path`, `sandbox_permissions`), each value a list of
   * regular-expression sources. A rule matches when the tool name matches AND
   * every listed key has at least one pattern matching its stringified value.
   * An empty `where` matches every call of the tool.
   */
  where?: Record<string, string[]>;
  /** Only match calls that carry `sandbox_permissions` (an escalation). */
  escalating?: boolean;
  /** Denial/approval note surfaced to the model or the log. */
  reason?: string;
}

/** Per-sandbox-mode review overrides: keys are `read-only` | `workspace-write` | `danger-full-access`. */
export interface PerModeReviewOverride {
  mode?: 'on' | 'off';
  allowModes?: string[];
  skipTools?: string[];
}

/**
 * Raw `review` config as accepted from YAML — every knob is optional and has a
 * runtime default (this is the input side of the Config schema).
 */
export interface ReviewConfigInput {
  /** 'on' enables the LLM reviewer (default), 'off' keeps rules only. */
  mode?: 'on' | 'off';
  /** Explicit reviewer provider route; must be paired with `model`. */
  provider?: string;
  /** Explicit reviewer model id; must be paired with `provider`. */
  model?: string;
  /** Tools never sent to the reviewer (defaults to read-only/control tools). */
  skipTools?: string[];
  /** Skip nested dispatches (e.g. run_code sub-calls); the outer call is reviewed. */
  skipNested?: boolean;
  /** Escalation modes the reviewer may grant (default includes danger-full-access; the static deny tier runs first). */
  allowModes?: string[];
  /**
   * Behavior when the reviewer is uncertain or unavailable:
   * 'ask' (default) — reviewer `ask` goes to the human, failures fall back silently;
   * 'deny' — fully-autonomous two-state mode: reviewer `ask` and failures both become deterministic denies.
   */
  onUncertain?: 'ask' | 'deny';
  /**
   * Per-sandbox-mode review overrides. The plugin follows the Access selector
   * dynamically: each key overrides `mode` / `allowModes` / `skipTools` for that
   * mode. Under `danger-full-access`, if `skipTools` was never customized,
   * everything is reviewed by default.
   */
  perMode?: Record<string, PerModeReviewOverride>;
  /** Per-review timeout in ms (default 20000). */
  timeoutMs?: number;
  /** Reviewer output token cap (default 512). */
  maxTokens?: number;
  /** Max input frame chars; longer arguments are truncated (default 12000). */
  maxInputChars?: number;
}

/** Raw config as accepted from YAML — the input side of the Config schema. */
export interface AutoApprovalConfigInput {
  /** Built-in destructive-command safety net toggle (default true). */
  builtinDeny?: boolean;
  /** Built-in destructive-command rules; defaults to the code-bundled list, editable without code changes. */
  builtinDenyRules?: Rule[];
  /** Extra hard-deny rules: matched calls are refused without prompting. */
  deny?: Rule[];
  /** Auto-allow rules: matched calls get the gate stamp that enables escalation auto-approval. */
  allow?: Rule[];
  answerer?: {
    /** Escalation modes allowed to auto-approve (default `['workspace-write']`; `danger-full-access` must be added explicitly). */
    allowModes?: string[];
    /** Approval reasons matching these regexes are auto-allowed. */
    allowJustifications?: string[];
    /** Approval reasons matching these regexes are auto-rejected (wins over allow). */
    denyJustifications?: string[];
  };
  /** LLM reviewer tier. */
  review?: ReviewConfigInput;
  /** Log auto-decisions (default true). */
  log?: boolean;
}

/**
 * Parsed config as passed to {@link apply} — schemastery has materialized every
 * default, so the fields that default at runtime are required here.
 */
export interface AutoApprovalConfig {
  builtinDeny: boolean;
  builtinDenyRules: Rule[];
  deny: Rule[];
  allow: Rule[];
  answerer: {
    allowModes: string[];
    allowJustifications: string[];
    denyJustifications: string[];
  };
  review: {
    mode: 'on' | 'off';
    provider?: string;
    model?: string;
    skipTools: string[];
    skipNested: boolean;
    allowModes: string[];
    onUncertain: 'ask' | 'deny';
    perMode: Record<string, PerModeReviewOverride>;
    timeoutMs: number;
    maxTokens: number;
    maxInputChars: number;
  };
  log: boolean;
}

/** Loader-facing config schema (schemastery). Validates and materializes defaults. */
export declare const Config: z<AutoApprovalConfigInput>;

export declare const name: string;

export declare function apply(ctx: Context, config: AutoApprovalConfig): void;
