import { clientBundle } from '../deepseek-harness/packages/client/tsdown.client.ts'

export default clientBundle('@deepseek-ai/dsh-notebooks', ['lib/types/index.js', 'lib/types/invariant.js'])
