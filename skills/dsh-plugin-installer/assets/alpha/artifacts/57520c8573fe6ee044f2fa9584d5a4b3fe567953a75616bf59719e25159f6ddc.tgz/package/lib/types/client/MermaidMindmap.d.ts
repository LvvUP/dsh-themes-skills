/** Render a Studio mindmap from Mermaid mindmap source. */
/** Draw an indented mindmap tree, or show a short error if the source is not a diagram. */
export declare function MermaidMindmap({ text, invalidLabel }: {
    text: string;
    invalidLabel: string;
}): import("react").JSX.Element | null;
//# sourceMappingURL=MermaidMindmap.d.ts.map