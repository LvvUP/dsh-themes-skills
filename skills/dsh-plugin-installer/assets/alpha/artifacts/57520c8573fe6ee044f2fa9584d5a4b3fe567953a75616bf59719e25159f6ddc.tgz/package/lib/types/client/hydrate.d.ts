/** Fill optional notebook fields after a Remote round-trip. */
import type { NotebookEntry } from '../types.ts';
/** Normalize a notebook for the workspace renderer. */
export declare function hydrateNotebook(entry: NotebookEntry): NotebookEntry;
//# sourceMappingURL=hydrate.d.ts.map