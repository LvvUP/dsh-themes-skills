/** Host generation prompts for notebook summaries and Studio artifacts. */
/** System prompt for an evidence-grounded notebook overview. */
export declare const SUMMARY_SYSTEM_PROMPT: string;
/** System prompt for a Mermaid mind map grounded in selected sources. */
export declare const MINDMAP_SYSTEM_PROMPT: string;
/** System prompt for a Markdown research report grounded in selected sources. */
export declare const REPORT_SYSTEM_PROMPT: string;
//# sourceMappingURL=prompts.d.ts.map