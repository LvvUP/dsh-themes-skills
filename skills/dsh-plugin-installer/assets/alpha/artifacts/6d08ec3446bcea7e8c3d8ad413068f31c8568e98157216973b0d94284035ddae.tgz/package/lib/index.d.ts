/**
 * Meta Memory Plugin for DeepSeek Harness.
 *
 * A structured long-term memory system that teaches the agent
 * how to organize memories using unit-based brief/full pairs.
 *
 * @module dsh-plugin-meta-memory
 */
export declare const name = "meta-memory";
export declare const inject: string[];
export interface Config {
    /** Path to the memory root directory. Defaults to $DSH_HOME/meta-memory. */
    memoryPath?: string;
    /** Custom SKILL.md path. Uses built-in if omitted. */
    skillPath?: string;
    /** Maximum bytes of briefs to inject into context. Default: 4096. */
    maxBriefBytes?: number;
    /** Enable automatic context injection of memory briefs. Default: true. */
    enableInjection?: boolean;
    /** Enable the skill teaching. Default: true. */
    enableSkill?: boolean;
}
export declare function apply(ctx: any, config?: Config): void;
declare const _default: {
    name: string;
    inject: string[];
    apply: typeof apply;
};
export default _default;
//# sourceMappingURL=index.d.ts.map