/**
 * Meta Memory file operations.
 * @module dsh-plugin-meta-memory/store
 */
/** Memory unit info. */
export interface UnitInfo {
    name: string;
    path: string;
    records: RecordInfo[];
}
/** Memory record info. */
export interface RecordInfo {
    index: number;
    name: string;
    briefPath: string;
    fullPath: string;
}
/** Initialize a meta-memory directory structure. */
export declare function initMemory(root: string): Promise<void>;
/** List all units in a memory root. */
export declare function listUnits(root: string): Promise<UnitInfo[]>;
/** List records in a unit directory. */
export declare function listRecords(unitPath: string): Promise<RecordInfo[]>;
/** Write a new memory record. */
export declare function writeRecord(root: string, unitName: string, recordName: string, brief: string, full: string): Promise<{
    unitPath: string;
    briefPath: string;
    fullPath: string;
}>;
/** Read all briefs from all units (for context injection). */
export declare function readAllBriefs(root: string): Promise<Array<{
    unit: string;
    name: string;
    brief: string;
}>>;
/** Read the index file. */
export declare function readIndex(root: string): Promise<string>;
/** Write the index file. */
export declare function writeIndex(root: string, content: string): Promise<void>;
/** Search briefs by keyword. */
export declare function searchBriefs(root: string, query: string): Promise<Array<{
    unit: string;
    name: string;
    brief: string;
    score: number;
}>>;
//# sourceMappingURL=store.d.ts.map