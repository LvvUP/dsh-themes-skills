#!/usr/bin/env node
/**
 * mm — meta memory CLI tool.
 *
 * Usage:
 *   mm init [path]              Initialize memory directory
 *   mm list [path]              List all units and records
 *   mm read <unit> [record]     Read brief or full record
 *   mm search <query> [path]    Search briefs by keyword
 *   mm index [path]             Show the index
 *
 * @module dsh-plugin-meta-memory/cli-mm
 */
export {};
//# sourceMappingURL=cli-mm.d.ts.map