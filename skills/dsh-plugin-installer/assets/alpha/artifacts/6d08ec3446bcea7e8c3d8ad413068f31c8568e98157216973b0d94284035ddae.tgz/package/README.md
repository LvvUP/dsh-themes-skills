# dsh-plugin-meta-memory

Structured long-term memory system for DeepSeek Harness.

## What it does

Teaches the agent how to organize memories using a structured system:
- **Units**: Work categories named `verb-modifier-noun.unit`
- **Records**: Each memory has a brief (quick scan) and full (detailed) version
- **Index**: Self-maintained global storyline
- **Auto-injection**: Relevant briefs are injected into context automatically

## Install

```sh
dsh plugin --profile your-profile add dsh-plugin-meta-memory
```

## How it works

### Memory structure

```
.meta-memory/
├── index.md
└── units/
    ├── debug-auth-module.unit/
    │   ├── 0.token-refresh-fail.brief.md
    │   └── 0.token-refresh-fail.full.md
    └── read-deeplearning-paper.unit/
        ├── 0.transformer-attention.brief.md
        └── 0.transformer-attention.full.md
```

### Brief format (injected into context)

```markdown
# token-refresh-fail
JWT token refresh returns 401 due to timestamp offset calculation error.
```

### Full format (loaded on demand)

```markdown
# token-refresh-fail

## Context
Auth module was failing on token refresh after 1 hour.

## Finding
expiresAt calculated using milliseconds instead of seconds.

## Evidence
src/auth/refresh.ts:42 - Math.floor(Date.now() / 1000) fixes it.

## Relevance
Any JWT/token related debugging in the future.
```

## CLI tool

```sh
mm init              # Initialize memory directory
mm list              # List all units and records
mm read <unit>       # Read all briefs in a unit
mm search <query>    # Search briefs by keyword
mm index             # Show the index
```

## Configuration

```yaml
- id: meta-memory
  name: dsh-plugin-meta-memory
  config:
    memoryPath: '~/.dsh/meta-memory'
    enableInjection: true
    enableSkill: true
    maxBriefBytes: 4096
```

## License

MIT -- YYTbit
