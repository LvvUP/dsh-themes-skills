/**
 * RAG (Retrieval-Augmented Generation) Plugin for DeepSeek Harness.
 *
 * Local knowledge base search: indexes project files and injects
 * relevant context into the system prompt based on the current task.
 *
 * @module dsh-plugin-rag
 */
export declare const name = "rag";
export declare const inject: string[];
export interface Config {
    /** Paths to index. Defaults to current working directory. */
    indexPaths?: string[];
    /** Maximum results to inject into context. Default: 3. */
    maxResults?: number;
    /** Maximum bytes of context injection. Default: 4096. */
    maxBytes?: number;
    /** Enable automatic context injection. Default: true. */
    enableInjection?: boolean;
    /** Enable the RAG skill. Default: true. */
    enableSkill?: boolean;
}
export declare function apply(ctx: any, config?: Config): void;
export { buildIndex } from './indexer.js';
export { search } from './search.js';
declare const _default: {
    name: string;
    inject: string[];
    apply: typeof apply;
};
export default _default;
//# sourceMappingURL=index.d.ts.map