#!/usr/bin/env node
/**
 * rag — local knowledge base search CLI.
 *
 * Usage:
 *   rag <query> [paths...]           Search files for relevant content
 *   rag --index [paths...]           Build and show index stats
 */
export {};
//# sourceMappingURL=cli-rag.d.ts.map