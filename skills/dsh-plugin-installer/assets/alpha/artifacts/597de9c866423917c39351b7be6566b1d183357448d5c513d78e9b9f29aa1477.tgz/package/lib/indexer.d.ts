/**
 * Document indexer for RAG.
 * Scans directories for files and builds a searchable index.
 * @module dsh-plugin-rag/indexer
 */
/** Indexed document. */
export interface IndexedDoc {
    path: string;
    relativePath: string;
    content: string;
    tokens: Map<string, number>;
}
/** Index statistics. */
export interface IndexStats {
    totalDocs: number;
    totalTokens: number;
    indexedPaths: string[];
}
/** Build an index from a list of directories. */
export declare function buildIndex(roots: string[]): Promise<{
    docs: IndexedDoc[];
    stats: IndexStats;
}>;
//# sourceMappingURL=indexer.d.ts.map