/**
 * Search engine for RAG.
 * TF-IDF style keyword search with relevance scoring.
 * @module dsh-plugin-rag/search
 */
import type { IndexedDoc } from './indexer.js';
/** Search result. */
export interface SearchResult {
    path: string;
    relativePath: string;
    score: number;
    snippet: string;
    matchedTerms: string[];
}
/** Search the index for relevant documents. */
export declare function search(docs: IndexedDoc[], query: string, limit?: number): SearchResult[];
//# sourceMappingURL=search.d.ts.map