# dsh-plugin-rag

Local knowledge base RAG for DeepSeek Harness.

## What it does

Indexes project files (markdown, code, configs) and provides keyword search to find relevant context. No external APIs or embedding models needed -- pure local TF-IDF search.

## Install

```sh
dsh plugin --profile your-profile add dsh-plugin-rag
```

## CLI

```sh
# Search for relevant files
rag "authentication" ./src

# Show index stats
rag --index ./src ./docs
```

## What gets indexed

- Markdown (.md, .txt)
- Code (.ts, .js, .py, .rs, .go, .java, .c, .cpp)
- Config (.json, .yaml, .toml, .env)
- Docs (.html, .xml, .sql, .graphql)

Skips: node_modules, .git, dist, build, __pycache__

## Configuration

```yaml
- id: rag
  name: dsh-plugin-rag
  config:
    indexPaths: ['.']
    maxResults: 3
    maxBytes: 4096
    enableInjection: true
```

## How it works

1. Scans directories for text files
2. Builds a keyword index (TF-IDF scoring)
3. Injects index stats into system prompt
4. Agent uses CLI to search when needed

No embedding models, no external APIs, no heavy dependencies.

## License

MIT -- YYTbit
